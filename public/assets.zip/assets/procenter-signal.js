// Signal
(function () {
 var tagjs = document.createElement("script");
 var s = document.getElementsByTagName("script")[0];
 tagjs.async = true;
 tagjs.src = "//s.btstatic.com/tag.js#site=GYp4tcM";
 s.parentNode.insertBefore(tagjs, s);
}());

var addNoScript = '<noscript><iframe src="//s.thebrighttag.com/iframe?c=GYp4tcM" width="1" height="1" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe></noscript>';

document.write( addNoScript );